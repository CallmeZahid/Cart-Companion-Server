const Item = require('./Item');
const User = require('./User');

const models = {
    Item,
    User
};

module.exports = models;