"A shopping list GraphQL API"

To run on local machine
1.Use npm install to download all dependencies
2.set up .env file
3.run using npm start
